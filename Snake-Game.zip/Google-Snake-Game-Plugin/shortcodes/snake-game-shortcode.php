<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Shortcode to display Google Snake Game.
 *
 * @return string HTML content to display the game.
 */
function google_snake_game_shortcode() {
    // Start output buffering.
    ob_start();

    // Here you can add your HTML and PHP code to output the game.
    // For example, you might use an iframe or a div container for your game.
    ?>
    <div id="google-snake-game-container">
             
             <iframe src="https://playgooglesnakegame.com/snake-classic/" width="600" height="400"></iframe>
       
    </div>
    <?php

    // Return the buffer content.
    return ob_get_clean();
}

// Register shortcode with WordPress.
add_shortcode( 'google_snake_game', 'google_snake_game_shortcode' );
