<?php
/**
 * Plugin Name: Google Snake Game
 * Plugin URI:  https://playgooglesnakegame.com/google-snake-game-plugin
 * Description: Integrates the Google Snake Game into WordPress posts and pages.
 * Version:     1.0
 * Author:      Akmal Yousuf
 * Author URI:  https://playgooglesnakegame.com
 * License:     GPL2
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define PLUGIN_PATH.
if ( ! defined( 'GOOGLE_SNAKE_GAME_PATH' ) ) {
	define( 'GOOGLE_SNAKE_GAME_PATH', plugin_dir_path( __FILE__ ) );
}

// Include the enqueue scripts.
require_once GOOGLE_SNAKE_GAME_PATH . 'includes/enqueue.php';

// Include the shortcode logic.
require_once GOOGLE_SNAKE_GAME_PATH . 'shortcodes/snake-game-shortcode.php';

// Optional: Include admin settings.
// require_once GOOGLE_SNAKE_GAME_PATH . 'admin/settings.php';

/**
 * Activation hook.
 */
function google_snake_game_activate() {
	// Activation code here.
}
register_activation_hook( __FILE__, 'google_snake_game_activate' );

/**
 * Deactivation hook.
 */
function google_snake_game_deactivate() {
	// Deactivation code here.
}
register_deactivation_hook( __FILE__, 'google_snake_game_deactivate' );

