<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Adds a settings page to the WordPress admin menu.
 */
function google_snake_game_add_admin_menu() {
    add_menu_page(
        'Google Snake Game Settings', // Page title
        'Snake Game Settings',       // Menu title
        'manage_options',            // Capability
        'google_snake_game',         // Menu slug
        'google_snake_game_settings_page', // Callback function
        'dashicons-admin-generic',   // Icon (Dashicon)
        81                           // Position
    );
}
add_action( 'admin_menu', 'google_snake_game_add_admin_menu' );

/**
 * Renders the settings page content.
 */
function google_snake_game_settings_page() {
    ?>
    <div class="wrap">
        <h1>Google Snake Game Settings</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields( 'google_snake_game' ); // Option group
            do_settings_sections( 'google_snake_game' ); // Page slug
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

/**
 * Initializes settings sections and fields.
 */
function google_snake_game_settings_init() {
    register_setting( 'google_snake_game', 'google_snake_game_settings' );

    add_settings_section(
        'google_snake_game_section', 
        __( 'Settings', 'wordpress' ), 
        'google_snake_game_settings_section_callback', 
        'google_snake_game'
    );

    add_settings_field( 
        'google_snake_game_field', 
        __( 'Custom Field', 'wordpress' ), 
        'google_snake_game_field_render', 
        'google_snake_game', 
        'google_snake_game_section' 
    );
}
add_action( 'admin_init', 'google_snake_game_settings_init' );

/**
 * Settings section callback function.
 */
function google_snake_game_settings_section_callback() {
    echo '<p>Customize the Google Snake Game settings.</p>';
}

/**
 * Renders the settings field.
 */
function google_snake_game_field_render() {
    $options = get_option( 'google_snake_game_settings' );
    ?>
    <input type='text' name='google_snake_game_settings[google_snake_game_field]' value='<?php echo $options['google_snake_game_field']; ?>'>
    <?php
}

