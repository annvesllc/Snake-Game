<?php
// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Enqueue plugin styles and scripts.
 */
function google_snake_game_enqueue_scripts() {
    // Enqueue the CSS for the Google Snake Game.
    wp_enqueue_style( 'google-snake-game-css', plugin_dir_url( __FILE__ ) . 'assets/css/style.css', array(), '1.0.0', 'all' );

    // Enqueue the JavaScript for the Google Snake Game.
    wp_enqueue_script( 'google-snake-game-js', plugin_dir_url( __FILE__ ) . 'assets/js/snake-game.js', array( 'jquery' ), '1.0.0', true );

    // Optional: If you have localized data for your script.
    // wp_localize_script( 'google-snake-game-js', 'snakeGameData', array(
    //     'ajax_url' => admin_url( 'admin-ajax.php' ),
    //     // Any other data you want to pass to your script.
    // ));
}

add_action( 'wp_enqueue_scripts', 'google_snake_game_enqueue_scripts' );
